FORM EXTRACTOR, Version 1.5
Copyright (C) 1999-2004 Zexer Research

INTRODUCTORY INFORMATION


DESCRIPTION
--------------------
A simple decompiler tool to extract forms and data modules from
executables created using Borland Delphi or C++ Builder.


REQUIREMENTS
--------------------
The system requirements for the program include the Pentium class
processor, 16MB of RAM, 1MB of free hard drive space and Windows
95/98/NT/2000/ME/XP.


INSTALLATION
--------------------
Unzip the ZIP archive to a temporary folder, double-click Setup.exe to
execute it. Setup will guide you through the rest of the installation
process.


UNINSTALLATION
--------------------
Open the Control Panel folder, double-click the "Add/Remove Programs"
icon. Select "Form Extractor" from the list, then click the "Add/Remove"
button. Follow the instructions that appear on the screen.


LICENSE AGREEMENT
--------------------
See LICENSE.TXT file.


ORDERING INFORMATION
--------------------
See ORDER.TXT file.


CONTACT INFORMATION
--------------------
You can contact the technical support service via e-mail:
support@zexersoft.com. Latest updates can be downloaded at
http://www.zexersoft.com/download.html
